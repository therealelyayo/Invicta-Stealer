1. Run Builder.exe

2. Input your discord webhook or URL to http server

3. Press build

4. Now stealer will be ready in 'out' folder

https://t.me/invicta_stealer join our telegram group for support